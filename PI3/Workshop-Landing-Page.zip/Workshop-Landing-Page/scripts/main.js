document.addEventListener('DOMContentLoaded', init)

function init() {
  $(".regular").slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 2000,
    dots: true,
    Infinity:true
  });
  
  $("#dateTimeInput").datetimepicker();

  $('body').sakura();

  // attach an event listener to the submit button 
  $("#bookHourBtn").on('click', validation);
}

function validation() {


  // selecting Dom Variables
  const username = document.querySelector("#username");
  const lecture = document.getElementsByTagName('select')[0]
  const instructor = document.getElementsByTagName('select')[1]
  const dateTime = document.getElementById("dateTimeInput");

  let  [date, time] = dateTime.value.split(' ');
  date = date.slice(5);

  let regex = /^[a-z]\w{3,25}/gi

  // Validation 
  if (!username.value || !dateTime.value) {
		$.notify("Please fill all form fields", "error");
		return;
  }
  
  if (!regex.test(username.value)) {
    $.notify('Username field incorrect', 'error');
    return
  }

  let section = document.querySelector('.education article:last-child')
  let ul = section.querySelector('.box-body ul');
  let span = section.querySelector('.box-footer span')

  let li = document.createElement('li');
  li.innerHTML = `
  
    <span>${instructor.value} - ${date} - ${time}</span>
     <i class="fas fa-chevron-circle-right"></i>
  `;

  ul.appendChild(li);
  

  // increase the span number 
  let num = Number(span.textContent)
  num++;
  span.textContent = num;
  
  $.notify('Access Granted', "success")
  username.value = '';
  dateTime.value = ''

}